package inventorysystem;

import static inventorysystem.SearchDisplay.con;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;

public class LoginEncoder extends JFrame implements ActionListener{
    
    
    private Connection conn = null;
    private Statement stmt = null;
    static String empty = "";
    
    public LoginEncoder(){
        try{
            connectToDB();  
            javax.swing.SwingUtilities.invokeLater(new Runnable(){
                public void run(){
                    createGUI(280,170);
                    addComponents();
                }
            });
        }catch(Exception e){
            System.out.println(e);
        }
        
        
    }
    
   public void connectToDB() throws Exception{
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/ImsDB", "mccp", "123");
        stmt = con.createStatement();
    }
    
    public void createGUI(int width,int height){
        this.setTitle("Encoder Login");
        this.setResizable(false);
        this.setSize(width, height);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(3);
        this.setVisible(true);
        
        
    }
    
    private JTextField tfUname;
    private JPasswordField tfPword;
    private void addComponents(){
        JLabel lblUname = new JLabel("Username : ");
        lblUname.setBounds(10,20,100,10);
        this.add(lblUname);
        
        JLabel lblPword = new JLabel("Password : ");
        lblPword.setBounds(10,50,100,10);
        this.add(lblPword);
        
        
        tfUname = new JTextField();
        tfUname.setBounds(80,16,150,20);
        this.add(tfUname);
        
        tfPword = new JPasswordField();
        tfPword.setBounds(80,46,150,20);
        this.add(tfPword);

        
        JButton btnLogin = new JButton("Login");
        btnLogin.setBounds(155,110,100,25);
        btnLogin.addActionListener(this);
        this.add(btnLogin);
        
        JButton btnBack = new JButton("Back");
        btnBack.setBounds(15,110,100,25);
        btnBack.addActionListener(this);
        this.add(btnBack);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if(command.equals("Login")){
            String uname = tfUname.getText();
            String pword = tfPword.getText();
   
            login(uname,pword);
        }
        
        if(command.equals("Back")){
            this.dispose();
            MenuPanel menuPanel = new MenuPanel();
            menuPanel.setVisible(true);
        }
            
        
    }
    
    private void login(String uname, String pword){
        String sql = "SELECT ID FROM ENCODER_ACCOUNTS WHERE USERNAME LIKE '"+uname+"' AND PASSWORD LIKE '"+pword+"' ";
        ResultSet rs = null;
        try{
            rs = stmt.executeQuery(sql);
            if(rs.next()){
                String msg = "Encoder Login Success";
                JOptionPane.showMessageDialog(null, "Login Success", msg, JOptionPane.PLAIN_MESSAGE);
                this.dispose();
                EncoderInsert insert = new EncoderInsert();
                insert.setVisible(true);
                insert.setEnabled(true);
            }else{
                System.out.println("Login Failed");
                JOptionPane.showMessageDialog(null, "Login Failed", "Access Denied", JOptionPane.ERROR_MESSAGE);
            }
        }catch(Exception e){
            System.out.println(e);
            
        }
    }
    
}
