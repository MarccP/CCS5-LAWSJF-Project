package inventorysystem;

import static inventorysystem.SearchDisplay.con;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;

public class LoginAdmin extends JFrame implements ActionListener{
    
    
    private Connection conn = null;
    private Statement stmt = null;
    static String empty = "";
    
    public LoginAdmin(){
        try{
            connectToDB();  
            javax.swing.SwingUtilities.invokeLater(new Runnable(){
                public void run(){
                    createGUI(280,170);
                    addComponents();
                }
            });
        }catch(Exception e){
            System.out.println(e);
        }
        
        
    }
    
   public void connectToDB() throws Exception{
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/ImsDB", "mccp", "123");
        stmt = con.createStatement();
    }
    
    public void createGUI(int width,int height){
        this.setTitle("Admin Login");
        this.setResizable(false);
        this.setSize(width, height);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(3);
        this.setVisible(true);
        
        
    }
    
    private JTextField tfUname;
    private JPasswordField tfPword;
    private void addComponents(){
        JLabel lblUname = new JLabel("Username : ");
        lblUname.setBounds(5,20,100,10);
        this.add(lblUname);
        
        JLabel lblPword = new JLabel("Password : ");
        lblPword.setBounds(5,50,100,10);
        this.add(lblPword);
        
        
        tfUname = new JTextField();
        tfUname.setBounds(80,16,150,20);
        this.add(tfUname);
        
        tfPword = new JPasswordField();
        tfPword.setBounds(80,46,150,20);
        this.add(tfPword);

        
        JButton btnLogin = new JButton("Login");
        btnLogin.setBounds(155,110,100,25);
        btnLogin.addActionListener(this);
        this.add(btnLogin);
        
        JButton btnBack = new JButton("Back");
        btnBack.setBounds(15,110,100,25);
        btnBack.addActionListener(this);
        this.add(btnBack);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if(command.equals("Login")){
            String uname = tfUname.getText();
            String pword = tfPword.getText();
   
            login(uname,pword);
        }
        
        if(command.equals("Back")){
            this.dispose();
            new MenuPanel();
        }
            
        
    }
    
    private void login(String uname, String pword){
        String sql = "SELECT ID FROM ADMIN_ACCOUNTS WHERE USERNAME LIKE '"+uname+"' AND PASSWORD LIKE '"+pword+"' ";
        ResultSet rs = null;
        try{
            rs = stmt.executeQuery(sql);
            if(rs.next()){
                String msg = "Admin Login Success";
                JOptionPane.showMessageDialog(null, "Login Success", msg, JOptionPane.PLAIN_MESSAGE);
                this.dispose();
                ManagePanel managePanel = new ManagePanel();
                managePanel.setVisible(true);
                managePanel.setEnabled(true);
            }else{
                System.out.println("Login Failed");
                JOptionPane.showMessageDialog(null, "Login Failed", "Access Denied", JOptionPane.ERROR_MESSAGE);
            }
        }catch(Exception e){
            System.out.println(e);
            
        }
    }
    
}
