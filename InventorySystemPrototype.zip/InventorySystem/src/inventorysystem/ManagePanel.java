/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventorysystem;




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.Period;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;


/**
 *
 * @author Marc
 */
public class ManagePanel extends javax.swing.JFrame {
    static String id = "";
    static String pass = "";
    static String user = "";
    static Connection con = null;
    static Statement stmt = null;
    static ResultSet rs = null;


  
    public ManagePanel() {
        try{
            connectToDB();  
            javax.swing.SwingUtilities.invokeLater(new Runnable(){
                public void run(){
                    initComponents();
                    addResultTable("");
                    
                }
            });
        }catch(Exception e){
            System.out.println(e);
        }

       
    }
    
    public void connectToDB() throws Exception{
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/ImsDB", "mccp", "123");
        stmt = con.createStatement();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Act_TxtFld = new javax.swing.JTextField();
        Create_Btn = new javax.swing.JButton();
        Pwd_TxtFld = new javax.swing.JTextField();
        Encoder_Lbl = new javax.swing.JLabel();
        Back_Btn = new javax.swing.JButton();
        Username_Lbl = new javax.swing.JLabel();
        Password_Lbl = new javax.swing.JLabel();
        Inventory_Lbl = new javax.swing.JLabel();
        UniquedID_Lbl = new javax.swing.JLabel();
        Id_TxtFld = new javax.swing.JTextField();
        Account_Btn = new javax.swing.JButton();
        Delete_Btn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Create_Btn.setText("Create");
        Create_Btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Create_BtnActionPerformed(evt);
            }
        });

        Encoder_Lbl.setText("ENCODER CREATION");

        Back_Btn.setText("Back");
        Back_Btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Back_BtnActionPerformed(evt);
            }
        });

        Username_Lbl.setText("USERNAME :");

        Password_Lbl.setText("PASSWORD :");

        Inventory_Lbl.setText("CURRENT INVENTORY RECORD");

        UniquedID_Lbl.setText("UNIQUE ID :");

        Account_Btn.setText("Display Accounts");
        Account_Btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Account_BtnActionPerformed(evt);
            }
        });

        Delete_Btn.setText("Delete");
        Delete_Btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Delete_BtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(Back_Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 88, Short.MAX_VALUE)
                        .addComponent(Account_Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Create_Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Delete_Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(Inventory_Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(196, 196, 196))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(Username_Lbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(UniquedID_Lbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(Password_Lbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Pwd_TxtFld)
                                    .addComponent(Act_TxtFld, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Id_TxtFld, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(Encoder_Lbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(Inventory_Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 266, Short.MAX_VALUE)
                .addComponent(Encoder_Lbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Id_TxtFld, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UniquedID_Lbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Act_TxtFld, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Password_Lbl)
                            .addComponent(Pwd_TxtFld, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(Username_Lbl))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Create_Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Back_Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Account_Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Delete_Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Create_BtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Create_BtnActionPerformed
        String unique = Id_TxtFld.getText();
        String uname = Act_TxtFld.getText();
        String pword = Pwd_TxtFld.getText();
     
        if(uname.isEmpty()){
            JOptionPane.showMessageDialog(rootPane, "Error : Username is Empty.","Error !",JOptionPane.ERROR_MESSAGE);
        }else if(pword.isEmpty()){
            JOptionPane.showMessageDialog(rootPane, "Error : Password is Empty.","Error !",JOptionPane.ERROR_MESSAGE);
        }else if(unique.isEmpty()){
            JOptionPane.showMessageDialog(rootPane, "Error : ID is Empty.","Error !",JOptionPane.ERROR_MESSAGE);
        }
        else{
            this.dispose();
            id = Id_TxtFld.getText();
            user = Act_TxtFld.getText();
            pass = Pwd_TxtFld.getText();
            AccountCreatedPanel create = new AccountCreatedPanel();
            create.setVisible(true);
        }
    }//GEN-LAST:event_Create_BtnActionPerformed

    private void Back_BtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Back_BtnActionPerformed
        this.dispose();
        MenuPanel Back = new MenuPanel();
        Back.setVisible(true);
        new MenuPanel();
    }//GEN-LAST:event_Back_BtnActionPerformed

    private void Account_BtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Account_BtnActionPerformed
        this.dispose();
        DisplayAccountPanel displayAccountPanel = new DisplayAccountPanel();
        displayAccountPanel.setVisible(true);
    }//GEN-LAST:event_Account_BtnActionPerformed

    private void Delete_BtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Delete_BtnActionPerformed
        String idconfirm = JOptionPane.showInputDialog("Enter Encoder ID :");
        int id = Integer.parseInt(idconfirm);
        int choose = JOptionPane.showConfirmDialog(null,"Are you sure you want to delete "+id+" ?","Confirmation",JOptionPane.YES_NO_OPTION);
        if(choose == JOptionPane.YES_OPTION){
            String sql = "DELETE FROM ENCODER_ACCOUNTS WHERE ID = "+id+"";
            
            try {
                stmt.executeUpdate(sql);
                JOptionPane.showMessageDialog(rootPane, "Successfully Deleted!");
            } catch (SQLException ex) {
                System.out.println(ex);
            }
        }else{
           
        }
    }//GEN-LAST:event_Delete_BtnActionPerformed
    JTable tblAccount;
    private void addResultTable(String accountName){
        Object[][] data = query(accountName);
        String[] columns = {"PRODUCT_NUM", "PRODUCT_MODEL" , "BRAND_NAME", "QUANTITY","PRICE","LOG"};
        tblAccount = new JTable(data,columns);
        tblAccount.setEnabled(false);
        
        
        
        JScrollPane sp = new JScrollPane(tblAccount);
        sp.setBounds(30,30,600,250);

        add(sp);
    }
    
    private Object[][] query(String uname){
        String sql = "SELECT * FROM INVENTORY";
        ResultSet rs = null;
      
        int totalRows = 0;

        try{
            rs = stmt.executeQuery(sql);
            while(rs.next()) totalRows+=1;
        }
        catch(Exception e){
            System.err.println(e);
        }


        Object[][] data = new Object[totalRows][6];
        try{
            rs = stmt.executeQuery(sql);
            int rowCount = 0;
            while(rs.next()){
                int id = rs.getInt("PRODUCT_NUMBER");
                String pmodel = rs.getString("PRODUCT_MODEL");
                String bname = rs.getString("BRAND_NAME");
                int quant = rs.getInt("STOCK_QUANTITY");
                double price = rs.getDouble("PRICE");
                String log = rs.getString("LOG");
              
                
                LocalDate localDate = LocalDate.parse(log);
                
                LocalDate today =LocalDate.now();
                Period p = Period.between(localDate, today);
                int test = p.getYears();
                
                Object[] row = new
            Object[]{id,pmodel,bname,quant,price,log};
                data[rowCount] = row;
                rowCount +=1;
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        return data;
    }
    
   
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try{
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/ImsDB", "mccp", "123");
            stmt = con.createStatement();
 
        }catch(Exception e){
            System.out.println(e);
        }
       
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManagePanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManagePanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManagePanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManagePanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManagePanel().setVisible(true);
            }
        });
    }
   
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Account_Btn;
    private javax.swing.JTextField Act_TxtFld;
    private javax.swing.JButton Back_Btn;
    private javax.swing.JButton Create_Btn;
    private javax.swing.JButton Delete_Btn;
    private javax.swing.JLabel Encoder_Lbl;
    private javax.swing.JTextField Id_TxtFld;
    private javax.swing.JLabel Inventory_Lbl;
    private javax.swing.JLabel Password_Lbl;
    private javax.swing.JTextField Pwd_TxtFld;
    private javax.swing.JLabel UniquedID_Lbl;
    private javax.swing.JLabel Username_Lbl;
    // End of variables declaration//GEN-END:variables
}
