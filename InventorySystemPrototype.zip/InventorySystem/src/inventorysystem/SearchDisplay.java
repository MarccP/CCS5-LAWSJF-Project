package inventorysystem;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;




public final class SearchDisplay extends JFrame implements ActionListener{
    static Connection con = null;
    static Statement stmt = null;
    static ResultSet rs = null;
    
    
    SearchPanel Display = new SearchPanel();
    
   public SearchDisplay(){
       try{
            connectToDB();  
            javax.swing.SwingUtilities.invokeLater(new Runnable(){
                public void run(){
                    createGUI(650,370);
                    addButton();
                    addResultTable(SearchPanel.search);  
                }
            });
        }catch(Exception e){
            System.out.println(e);
        }
        
    }
   
    
    
    private void createGUI(int width, int height){
        this.setSize(width, height);
        this.setTitle("Result Panel");
        this.setResizable(false);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(3);
        this.setVisible(true);
        
    }
    
     public void connectToDB() throws Exception{
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/ImsDB", "mccp", "123");
        stmt = con.createStatement();
    }
    JButton btnBack,btnAgain;
    private void addButton(){
        btnBack = new JButton("Back");
        btnBack.setBounds(30, 300, 150, 40);
        btnBack.addActionListener(this);
        this.add(btnBack);
        
        btnAgain = new JButton("Search Again");
        btnAgain.setBounds(200, 300, 150, 40);
        btnAgain.addActionListener(this);
        this.add(btnAgain);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if(command.equals("Back")){
            this.dispose();
            DisplayAll Display = new DisplayAll();
            Display.setVisible(true);
        }
        
        if(command.equals("Search Again")){
            this.dispose();
            SearchPanel SearchPanel = new SearchPanel();
            SearchPanel.setVisible(true);
        }
       
    } 
    
     JTable tblAccount;
    private void addResultTable(String PRODUCT_MODEL){
        Object[][] data = query(PRODUCT_MODEL);
        String[] columns = {"PRODUCT_NUM", "PRODUCT_MODEL" , "BRAND_NAME", "QUANTITY","PRICE"};
        tblAccount = new JTable(data,columns);
        tblAccount.setEnabled(false);
        
        JScrollPane sp = new JScrollPane(tblAccount);
        sp.setBounds(30,30,600,250);

        add(sp);
    }
    
    private Object[][] query(String product_model){
        String sql = "SELECT * FROM INVENTORY WHERE PRODUCT_MODEL LIKE '%"+product_model+"%'";
        ResultSet rs = null;
      
        int totalRows = 0;

        try{
            rs = stmt.executeQuery(sql);
            while(rs.next()) totalRows+=1;
        }
        catch(Exception e){
            System.err.println(e);
        }


        Object[][] data = new Object[totalRows][5];
        try{
            rs = stmt.executeQuery(sql);
            int rowCount = 0;
            while(rs.next()){
                int id = rs.getInt("PRODUCT_NUMBER");
                String pmodel = rs.getString("PRODUCT_MODEL");
                String bname = rs.getString("BRAND_NAME");
                int quant = rs.getInt("STOCK_QUANTITY");
                double price = rs.getDouble("PRICE");
               
             
                Object[] row = new
            Object[]{id,pmodel,bname,quant,price};
                data[rowCount] = row;
                rowCount +=1;
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        return data;
    }
    
}



